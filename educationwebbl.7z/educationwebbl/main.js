function login(){
    var name = document.getElementById('a').value
    localStorage.setItem("name",name)
    window.location = "educate50.html"
}




///<h3 id="name">訪客</h3>